import "./App.css";
import React, { useState, useEffect } from "react";
import starshipImage from './trophy.png'; 

function App() {
  const url = "https://swapi.dev/api/starships/";
  const [data, setData] = useState([]);

  const fetchInfo = () => {
    return fetch(url)
      .then((res) => res.json())
      .then((d) => setData(d))
     
  }


  useEffect(() => {
    fetchInfo();
   //console.log("api data", data.results);
   
  }, []);
  
  return (
    <div className="App">
      <h1 style={{ color: "#66D3FA" }}>Govardhan Frontend Test</h1>
      <center>
        {data.results?.map((dataObj, index) => {


          const imageStyle = {
            width: '20px' 
          };

         
          return (
            <div
              style={{
                width: "20em",
                backgroundColor: "#3C99DC",
                padding: 2,
                borderRadius: 10,
                marginBlock: 10,
              }}
            >
              <p style={{ fontSize: 20, color: 'white' }}><img src={starshipImage} alt="Starship" style={imageStyle}/> {dataObj.name}</p>
              <p style={{ fontSize: 20, color: 'white' }}>{dataObj.model}</p>
              <p style={{ fontSize: 20, color: 'white' }}>{dataObj.films.length}</p>
              <p style={{ fontSize: 20, color: 'white' }}>{dataObj.crew}</p>
            </div>
          );
        })}
      </center>
    </div>
  );
}

export default App;